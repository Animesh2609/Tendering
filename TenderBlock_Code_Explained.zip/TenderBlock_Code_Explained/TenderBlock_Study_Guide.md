# TenderBlock: understand the project and its code

Reviewed on 17 November 2026. Repository: https://github.com/srijangdas/TenderBlock. Main resolves to `244c06c9e43b218eee02e05f3b5fa36a3f676fdd`, committed 9 November 2026. This is the same revision used for the latest documentation comparison in this conversation. “Final version” is the team's description; the review below describes the code actually present.

This guide is a source walkthrough, not a new live acceptance-test result. The accompanying code reader preserves original paths and line numbers. Read a function's purpose first, then its individual line notes. Library source in `vendor/`, dependency lockfiles and the Maven wrapper are identified separately: those are supporting third-party/generated files, rather than the team's tender logic.

## 1. What the project does

TenderBlock manages a procurement process. An organization announces work it needs done; companies submit quotations and a PDF proposal; an assigned evaluator scores the bids; the system records a winning bid. An auditor can compare database records with fingerprints saved in Hyperledger Fabric and investigate discrepancies.

For example, a college might request a laboratory renovation with an estimated value of INR 10 lakh. The Lister writes the request. Admin checks and publishes it, assigning an Evaluator. Three approved Bidders submit prices and PDFs before the deadline. The Evaluator opens and scores them after the opening time. Java ranks the finalized scores and records the award. The Auditor has separate tools for checking whether committed tender/bid information has changed.

The important boundary: Java currently makes the normal award decision. The Go smart contract does not evaluate bids, choose the winner or enforce the full tender lifecycle. It stores and retrieves integrity commitments. A cryptographic match says the compared bytes match the commitment; it does not prove the original claim was truthful or that procurement was fair.

## 2. Every user-facing capability, by actor

### Shared account and interface features

- Public landing and access pages lead to registration, public login or staff login. Existing signed-in users are directed to their role's workspace.
- Public registration is for Bidder/Lister. There is a separate Evaluator application form. Java role names are CONTRACTOR and AUTHORITY; the UI maps them to BIDDER and LISTER.
- Registration returns a session immediately, but a new user's account defaults to PENDING. Being signed in does not mean being approved to bid or create tenders.
- Passwords are BCrypt-hashed on the backend. Login returns a signed JWT valid for one hour. The shared frontend session is stored in sessionStorage. Logout clears the browser session; no server-side token revocation mechanism is implemented here.
- Pending accounts refresh `/auth/me/status` on relevant window/tab events so Admin approval can appear without creating another account.
- Shared route guards redirect users to the appropriate workspace. These are navigation controls; backend authorization remains essential for direct API requests.
- Loading, empty, success and error states explain requests; a 401 clears an authenticated session. A React error boundary provides a fallback for render errors.
- Light/dark preference is shared across the three former UI modules and saved locally. Tables, sidebars and layouts include responsive styling.

### Lister / AUTHORITY

- Creates and updates company information: company name, registration number, GSTIN, PAN, address, contact number and website. Account registration and company-profile creation are two separate API calls. A failed profile save does not erase the newly created account.
- Sees a dashboard with tender counts and recent requests, and a paginated list of owned tenders.
- Creates a tender with title, description, estimated value, submission deadline and opening date. Java requires a verified AUTHORITY, positive money and correctly ordered future dates. New tenders are SUBMITTED for Admin review, not immediately published.
- The backend permits editing an owned SUBMITTED tender and updates its commitment. An edit route/component remains in the frontend, but the current My Tenders table exposes cancellation rather than an Edit button. A file existing in the repository does not guarantee a visible navigation control reaches it.
- Cancels owned tenders with a reason under the permitted policy. Java allows PUBLISHED or UNDER_EVALUATION; the current visible cancellation UI is narrower and requires a published tender before cutoff.
- Reads an owned tender's award summary through an implemented API; distinguish endpoint availability from the exact button exposed on each screen.

### Bidder / CONTRACTOR

- Browses published tenders, sees details, searches the loaded table and uses pagination. In team mode, keyword search is local to the fetched page, not a server-wide search.
- The source includes sector-matching recommendation behavior for data with sector fields. Current Java tender DTOs do not supply sector, so the UI falls back to showing the available published tenders. This is a simple equality filter, not machine learning.
- A verified Bidder prepares one bid per tender: create a draft quotation, upload one proposal PDF, then explicitly submit. Drafts have an ID so upload retries reuse the same draft rather than creating another bid.
- Can save a draft and return from My Bids. Can update a draft or an already submitted quotation/PDF before cutoff while the tender remains PUBLISHED. A submitted edit updates the commitment and does not submit a second bid.
- Own-bid pages display statuses, dates and proposal availability; authorized PDF download includes a bearer header. Tokens are not placed in download URLs.
- Java checks file presence, size at most 10 MB, PDF MIME type and `%PDF-` signature. The frontend defaults to a lower configurable 1 MB limit; actual Spring multipart limits must also agree. Header checks are not a full PDF security scan.
- Server checks ownership, verification, tender status and time, independent of disabled buttons. WITHDRAWN exists in the bid enum, but there is no corresponding withdrawal controller operation in this snapshot.

### Admin

- Reviews pending user applications; verify/reject controls update account status.
- Backend APIs additionally list users, show account/company details and disable/enable eligible accounts. The merged interface does not expose every administrative API.
- Reviews SUBMITTED tenders. Approval must select a verified EVALUATOR, creates a TenderEvaluator assignment and publishes the tender. Rejection records REJECTED plus a reason.
- A tender-document API wrapper remains in frontend code, but its server endpoint is absent and the visible approval-screen document control has been removed. Do not present this as an implemented upload/download feature.
- Admin registration is explicitly prohibited. This checkout does not supply an initial Admin seed/migration, so the team needs an authorized bootstrap method outside the public registration form.

### Evaluator

- Sees assigned tenders with active/history separation and opening date/time displayed in IST.
- Explicitly opens submitted bids after openingDate. This changes bid states to OPENED and the tender to UNDER_EVALUATION. Passing submissionDeadline alone does not open bids.
- Reads assigned bid details and authorized PDFs after opening. Stored PDF bytes are hash-checked before download.
- Enters technical and financial scores from 0 to 100, with at most two decimal places, and remarks. Saves an editable evaluation draft, then finalizes it. Finalization locks that evaluation and marks the bid EVALUATED.
- Java calculates total = (technical + financial) / 2, rounded HALF_UP to two decimals. These are evaluator-entered scores; financial scoring is not automatically inferred from price by an ML model.
- When all relevant bids have finalized evaluations, Java automatically selects the winner. Ties prefer higher technical score, lower quoted amount, earlier submission and finally the maximum under Java UUID comparison. With `.max(...)`, the reversed comparators for amount/time make lower/earlier values preferable.
- The winning bid becomes SELECTED; the others become NOT_SELECTED; a TenderAward is saved; the tender becomes AWARDED. This is triggered by evaluator finalization, not a separate final Admin award button.

### Auditor

- Sees a review queue of UNDER_EVALUATION tenders, ON_HOLD flagged tenders, reports and a completed queue currently backed by award records.
- Requests a fresh audit using POST. Opening audit details can create reports and change an eligible tender's state; this is not just a passive GET.
- Recomputes the tender payload hash; checks committed record existence and payloadHash; verifies PDF bytes against the stored SHA-256; recomputes bid payload hashes and compares them to Fabric.
- A missing commitment or mismatching hash is a discrepancy. A network/read failure returns NOT_CHECKED/unavailable, rather than incorrectly claiming verified integrity.
- The report service avoids duplicating an active report for the same tender, optional bid and issue type. An eligible unawarded tender is placed ON_HOLD.
- Claims an OPEN report, becoming the assigned investigator and moving it to UNDER_REVIEW. Only the assigned Auditor may resolve it.
- A confirmed issue marks the report RESOLVED and can VOID the held, unawarded tender. A rejected allegation marks the report DISMISSED; dismissal itself leaves the tender ON_HOLD.
- A separate held-award operation accepts a winning bid ID and remarks. It requires no active reports, an eligible same-tender bid with finalized evaluation, and every relevant bid evaluated. It does not rerun the normal ranking comparator to prove that the Auditor's chosen bid is highest-ranked.

### System actions

- A scheduler, enabled by the application entry point, runs every 60 seconds by default. It cancels expired PUBLISHED tenders with no SUBMITTED bids, recording a system reason and cancellation time. DRAFT bids do not count as submissions.
- Backend validation, transaction boundaries, document hashing, request authorization and standardized error responses support the screens.
- A separate explicit demo mode stores simulated data in the browser. It is useful offline for interface demonstrations, but does not provide Java authorization, database persistence or a Fabric transaction. It does not retain real downloadable proposal files.

## 3. The architecture in plain language

Browser (React) -> HTTP JSON/multipart requests -> Spring controllers -> Java services -> JPA repositories -> PostgreSQL.

For selected writes/audits: Java services -> BlockchainRecordService -> FabricService -> TLS/gRPC Fabric Gateway -> deployed Go chaincode -> Fabric world state and ledger.

React draws the screens and collects input. A controller is the API doorway. A service applies the business rule. A repository loads/saves database objects. A DTO defines fields allowed across the API. An entity defines how a Java object maps to a database table. Fabric is another running system; it is not started simply because the Go source exists in the repository.

The database contains nine main entity types: User, CompanyProfile, Tender, TenderEvaluator, Bid, BidDocument, BidEvaluation, TenderAward and IntegrityReport. A user can own multiple tenders or bids; a tender has one evaluator assignment; a bid has at most one proposal and one evaluation; a tender has at most one award. UUIDs identify records. Unique constraints include email, tender+contractor and tender award.

PostgreSQL stores proposal bytes in a BYTEA column. SHA-256 fingerprints are deterministic 64-character hexadecimal strings. They are not encryption and cannot reconstruct the PDF. Fabric stores a second commitment to selected structured data, including the proposal hash for a bid.

## 4. Statuses and the actual tender journey

S / SUBMITTED: a Lister created a request waiting for Admin.

P / PUBLISHED: approved; bids may be prepared/submitted while time permits.

R / REJECTED: Admin refused the request; terminal for that request.

U / UNDER_EVALUATION: assigned Evaluator opened submitted bids after the opening time.

O / ON_HOLD: an integrity issue pauses an eligible tender for investigation.

A / AWARDED: a winner and award are recorded.

C / CANCELLED: owner cancellation or automatic no-submitted-bids cancellation.

V / VOIDED: an Auditor confirmed an issue and invalidated the held tender.

Normal source route: SUBMITTED -> PUBLISHED -> UNDER_EVALUATION -> AWARDED. Branches: SUBMITTED -> REJECTED; PUBLISHED/UNDER_EVALUATION -> CANCELLED under service rules; eligible UNDER_EVALUATION -> ON_HOLD -> AWARDED or VOIDED under investigation rules. Not every imaginable transition is allowed.

Keep four other vocabularies separate: account PENDING/VERIFIED/REJECTED/DISABLED; bid DRAFT/SUBMITTED/OPENED/UNDER_EVALUATION/EVALUATED/SELECTED/NOT_SELECTED (plus unused WITHDRAWN); evaluation DRAFT/FINALIZED; report OPEN/UNDER_REVIEW/RESOLVED/DISMISSED. Award.verificationStatus also starts PENDING even when the tender is AWARDED; that is not a contradiction because they describe different things.

## 5. Walk through one bid across all three codebases

1. React `App.jsx` routes a BIDDER to its workspace. `RequireRole.jsx` checks the stored session for navigation; `AuthContext.jsx` supplies the token.
2. `TenderDetailsPanel.jsx` selects the appropriate bid component. In live team mode, `BidForm.jsx` renders `TeamBidForm.jsx`.
3. `TeamBidForm.handleSave` validates money/PDF, keeps any existing draft ID and chooses `bidApi.createDraft` or `updateDraft`. `services.js` delegates to the injected transport adapter in `teamBidClient.js`.
4. `http.js` sends POST `/api/v1/bids/tender/{tenderId}` with a JSON quotedAmount and Authorization bearer token. The Vite dev proxy forwards `/api/v1` to the configured Java host, default localhost:8080.
5. `JwtFilter` verifies the token signature/expiry and fills Spring's security context. `BidController.createBid` binds the UUID and validated request and passes the authenticated user to `BidService`.
6. `BidService.createBid` looks up the user, requires a verified CONTRACTOR, checks the tender is PUBLISHED and before cutoff, rejects an existing bid and saves a DRAFT with BigDecimal quotation.
7. React sends PUT `/bids/{id}/proposal` with FormData field `file`. Java validates bytes, computes SHA-256 and saves BidDocument in PostgreSQL. Draft upload alone does not create a BID commitment.
8. React sends POST `/bids/{id}/submit`. Java requires DRAFT, an uploaded proposal and open intake, then sets SUBMITTED and a microsecond-precision timestamp.
9. `BlockchainRecordService.createBidRecord` verifies the PDF's local hash and builds a stable LinkedHashMap of bid ID, tender ID, contractor ID, quoted amount, submittedAt and proposalSha256. ObjectMapper serializes it; DocumentHashService computes SHA-256.
10. `FabricService.createIntegrityRecord` submits `CreateRecord` with ID `BID:<uuid>`, type BID, parent `TENDER:<uuid>` and the payload hash. The Go method validates type/hash, rejects duplicates, uses the transaction timestamp and calls PutState.
11. After the transaction calls succeed, Java returns a BidResponse and React displays the server-confirmed reference. A later audit recalculates the same payload hash and compares it with ReadRecord's payloadHash.

There are two separate persistence systems. A Java @Transactional boundary covers the database work; it does not make PostgreSQL and Fabric a single atomic transaction. Fabric could commit and the database later fail. A timed-out submission can have an uncertain outcome. The source has synchronous calls and 503 errors, but no durable outbox/reconciliation process establishing automatic recovery from every such case.

## 6. How to read the Java code

Start with `PureTenderApplication.java`, then `SecurityConfig`, `JwtFilter`, one controller, its service, its DTO/entity and the repository it uses. The code reader includes every application Java file and line, plus the SQL migration and build configuration.

`@SpringBootApplication` starts component scanning and framework configuration. `@EnableScheduling` enables the no-bids timer. `@RestController` exposes JSON API methods. `@RequestMapping` adds a URL prefix; `@GetMapping`, `@PostMapping`, `@PutMapping` and `@PatchMapping` map a method+path. `@Valid @RequestBody` binds and validates JSON. `@PathVariable` reads a URL segment. `Authentication` represents the verified caller. `ResponseEntity` controls status, headers and body.

`@Service` makes a class injectable. `@RequiredArgsConstructor` lets Lombok generate a constructor for final dependencies; the missing constructor text is generated code, not a forgotten file. `@Transactional` joins a database transaction; readOnly requests a read-oriented one. JPA dirty checking can save changes to a managed entity at commit even where there is no explicit repository save, as in the scheduler.

`@Entity`/`@Table` describe database mapping. `@Id`/`@GeneratedValue(UUID)` give an identifier. `@ManyToOne`/`@OneToOne` describe relationships. LAZY defers related-object loading. `@Enumerated(STRING)` stores enum names. `@PrePersist` and `@PreUpdate` fill timestamps. Lombok generates getters/setters and no-argument constructors.

A Java record is a compact data carrier, used for DTOs. BigDecimal handles exact decimals; Instant handles a UTC time point; UUID identifies records; Optional represents a lookup that may fail. `.orElseThrow(...)` makes the absent-record decision explicit. A Spring Data method such as `findByTender_IdAndContractor_Id` is turned into a query by the framework; a handwritten SQL file for every method is unnecessary.

`SecurityConfig` makes authentication stateless, installs JWT filtering and configures public/authenticated routes plus method security. AuthService normalizes emails, hashes/checks passwords, denies Admin registration and rejects disabled/rejected logins. JwtUtil signs HMAC256 tokens for one hour. Its refresh-token generator is only a helper; the repository does not expose a complete refresh-token endpoint/session lifecycle.

The JSON authentication/access-denied handlers explain 401/403. ApiExceptionHandler serializes ResponseStatusException into ApiSecurityError with request context. Do not assume this handler covers every unrelated exception or all validation errors in an identical shape.

## 7. How to read the React code

`index.html` contains the root element. `main.jsx` mounts React, wraps the app in BrowserRouter, ThemeProvider, AuthProvider and ErrorBoundary, and imports shared/scoped styles. `App.jsx` defines routes. `StaffWorkspacePage.jsx` lazy-loads the Evaluator workspace or Admin/Auditor workspace; this avoids loading every staff screen immediately.

Components are JavaScript functions returning JSX, which describes interface elements. Props are inputs from a parent. `useState` remembers data and schedules a rerender when its setter is called. `useEffect` connects loading/listeners to a component's lifetime, with cleanup. `useContext` reads shared session/theme data. `useMemo` caches a calculated result; `useCallback` stabilizes a function identity; `useRef` keeps a mutable reference without a rerender.

`async`/`await` waits for request results. `try/catch/finally` separates success, failure and cleanup. Optional chaining (`?.`) safely reads a possibly absent value; nullish coalescing (`??`) uses a fallback for null/undefined. Object spread (`...old`) copies fields so state updates can replace objects without mutating the old state. `.map` renders a list, `.filter` narrows it; `key` helps React track list entries.

`services.js` chooses the live team adapter, older integration adapter or demo store. The current default is team. `contracts.js` maps visible form fields to actual backend DTOs and defines URL builders; `dtos.js` normalizes server field/role names into UI data. Neither is a second backend.

`http.js` handles common fetch logic: JSON versus FormData, bearer headers, aborts, empty/204 responses, binary downloads and errors. A 401 with a supplied token dispatches the shared expiry event. 502/503/504 messages help distinguish an unavailable backend from a running frontend screen.

Money is deliberately handled with strings around transport. `exactMoney` validates up to 17 integer digits and two decimals; `parseApiJson` preserves money fields before normal JavaScript Number parsing can round them. Display conversion through Number is not an arbitrary-precision accounting implementation. `dateTime.js` interprets entered clocks as IST (+05:30) and sends UTC ISO instants so the laptop's timezone does not shift the tender cutoff.

The former Evaluator and Operations modules retain their component/CSS organization but re-export the shared useAuth/useTheme hooks. Their API files use the shared transport. This is how modular frontend pieces became one session and one React application, rather than three independent logins.

Styling comes from Tailwind plus shared CSS and styles scoped under evaluator-portal/operations-portal. CSS determines appearance and responsive layout, not authorization or persistence. The original module CSS under `styles/` supports the style-scoping script; it is not a second active application.

## 8. How Hyperledger works here, including every contract operation

Hyperledger Fabric is permissioned: network identities and channel policy determine who participates. The Java service uses one configured Org1 user identity for its Fabric operations. Application JWT roles and Fabric MSP identities are different systems; a Bidder's web login is not a separately enrolled Fabric certificate in this code.

`FabricService.init` reads five required configuration values; resolves Org1 certificate, private-key and peer TLS-CA files; creates a trusted TLS gRPC connection; builds an X509 identity and private-key signer; connects a Gateway with timeouts; then chooses the configured channel and deployed chaincode ID. Missing files can prevent backend startup. Shutdown closes the Gateway and gRPC channel.

`evaluateTransaction` queries without submitting a new ledger write. `submitTransaction` endorses/submits a state-changing transaction through the gateway. A successful API result is not a separately displayed receipt: the current DTO does not return a durable transaction ID/commit receipt to the screen.

The Go file `chaincode/puretender/main.go` has 242 lines and is fully included in the code reader. It defines SmartContract, IntegrityRecord and a legacy sample Asset.

- SmartContract embeds contractapi.Contract so Fabric's Go contract library can expose its methods.
- IntegrityRecord stores recordId, recordType, parentId, payloadHash, createdAt and updatedAt. It does not store plaintext quotation, PDF, score, tender status or winner.
- CreateRecord validates a nonempty ID, allowed TENDER/BID type and 32-byte hex hash, checks absence, gets the Fabric transaction timestamp, constructs the record and writes JSON with putRecord.
- UpdateRecord checks ID/hash syntax, reads an existing record, replaces its payload hash and updatedAt, preserving createdAt/type/parent. Its validation call supplies the literal TENDER even for an existing BID; it does not actually change the stored type. This is generic hash update code, not a tender publication action.
- ReadRecord gets bytes from world state, fails if missing and unmarshals JSON into a record.
- RecordExists asks GetState and returns whether non-nil bytes exist. It does not itself compare a hash or enforce record-type ownership.
- GetAllRecords scans the range BID: through TENDER;, filters BID:/TENDER: prefixes, decodes records and returns an array. Current world state contains the latest value for each key; earlier successful writes are in the ledger history, but no GetHistoryForKey API is implemented here.
- validateRecord decodes the hexadecimal string and requires 32 bytes (SHA-256). It does not prove a parent tender exists or enforce the web application's roles.
- transactionTime uses the transaction-provided timestamp, rather than a local machine's wall clock during endorsement, and formats UTC RFC3339Nano.
- putRecord serializes and writes under RecordID. PutState prepares a world-state update for the transaction; the network's endorsement/order/validation process determines its eventual commit.
- CreateAsset/GetAllAssets preserve the old sample API. They deal with color/size/owner/appraisedValue and ASSET: keys; these are demonstration assets, not the tender domain.
- main constructs the chaincode from SmartContract and starts it; startup errors panic.

BlockchainRecordService uses LinkedHashMap to preserve field insertion order and decimal strings to make commitments reproducible. Tender commitments include id/title/description/value/deadline/opening/authority. Bid commitments include id/tenderId/contractorId/quotedAmount/submittedAt/proposalSha256. Compatible serialization is essential: hashing the same information in a different byte order gives a different hash.

The chaincode does not contain application-level caller-role checks for these methods. Deployment/channel/endorsement policies and protection of the Java service's signer are therefore important. The public legacy `/api/blockchain/**` controller routes are explicitly permitted by SecurityConfig; remove or restrict sample write APIs before exposing a deployment.

## 9. Local files, services and “offline code”

Some local material is expected and intentionally absent. Source inspection can identify references to it; it cannot reveal what is actually on a teammate's laptop.

- `PureTender/src/main/resources/application.properties` is ignored and absent. Supply database URL/user/password, JWT signing secret and Fabric properties through suitable local configuration/environment. Do not publish secrets or put them in VITE_ variables, which become browser-visible settings.
- Fabric requires `fabric.crypto-path`, `fabric.peer-endpoint`, `fabric.peer-hostname`, `fabric.channel` and `fabric.chaincode`. The actual Org1 paths below crypto-path are hardcoded in FabricService. Copying an arbitrary crypto directory or using the wrong enrolled user will not match those paths.
- Fabric network artifacts are outside this application source: peer/orderer containers and data, identities, TLS certificates, channel creation, chaincode packaging/install/approval/commit. The setup notes point to fabric-samples/test-network on Ubuntu/WSL; the exact laptop path in those notes must be replaced. Validate the channel creation/join sequence; the note's short `network.sh up`/deployCC sequence is not a complete reproducible channel bootstrap.
- The code has no fallback for fabric.channel or fabric.chaincode in @Value. The chaincode README mentions the deployment name basic; the team's actual local property must match the deployed name.
- PostgreSQL must run with a suitable database/schema. JPA annotations describe tables but do not prove the local schema-creation setting. The only committed Flyway SQL is V2, conditionally relaxing an old bids.technical_proposal NOT NULL field. It is not a complete fresh-database creation migration.
- An initial verified ADMIN must exist through an authorized bootstrap procedure; public registration cannot create one. No committed bootstrap seed was found.
- Java 21, Maven wrapper support, Node >=22.12, npm dependencies, Go modules and Fabric binaries/containers are tools/dependencies. node_modules, compiled classes, target and dist are generated outputs, not missing handwritten features. Vendored Go dependencies are already committed under the contract's vendor folder.
- Frontend `.env.demo` and `.env.live` contain public mode settings. A local VITE_BACKEND_TARGET can point the development proxy at the real backend. Production requires a hosted frontend, SPA route fallback and API reverse proxy; Vite's development proxy does not configure production automatically.
- Local databases contain actual accounts/tenders/bids; Git does not carry that data. Browser storage also does not transfer between teammates or laptops.

To run the UI locally: cd pure-tender-web; npm ci; npm run dev. It normally calls the Java backend through localhost:8080. `npm run dev:demo` explicitly uses browser-only simulated data. To build: npm run build. To run Java: cd PureTender; ./mvnw spring-boot:run, after configuring PostgreSQL/Fabric/JWT and starting the required services. The source walkthrough did not start these external services or prove they are configured correctly.

Ordinary “offline development” means teammates can work on local source and commit it later. It does not mean those uncommitted features already exist. Offline demo mode is implemented; live Fabric-backed operation needs a reachable running Fabric network, which can itself run locally without public Internet once dependencies and images are available.

## 10. What remains different from the board, and sensible next work

1. Mandatory integrity gate: the whiteboard asks for DB/Fabric verification after scoring and before award. The normal automatic-award helper does not invoke auditTender/checkLedgerRecord. Add a deliberate verified gate and define what happens when Fabric is unavailable.
2. Early hold recovery: an audit can hold a tender before every evaluation is finished. Scoring requires UNDER_EVALUATION; dismissing a report leaves ON_HOLD; held award requires all bids evaluated. Add a guarded return-to-evaluation path after reports are cleared, then retest it.
3. Full lifecycle ledger records: the board wants rejection/cancellation/award/winner/void updates on-chain. The current commitment excludes tender status and winner and those service paths have no lifecycle-specific ledger write. Add a versioned event/schema and query/receipt strategy if this remains a requirement.
4. Completed records: AuditorService's completed queue uses TenderAwardRepo, so it does not represent every A/C/R/V terminal tender. Query all accepted terminal states if the board remains authoritative.
5. Reproducible setup: provide example configuration without secrets, complete schema migrations, an authorized Admin bootstrap and scripted Fabric deployment. Fix the differently cased Puretender crypto ignore path for case-sensitive systems.
6. Recovery/concurrency: add idempotency and durable reconciliation across PostgreSQL/Fabric; test duplicate submissions, uncertain commit outcomes and concurrent evaluation/report actions. A transaction annotation alone does not solve these.
7. Security policy: restrict the sample blockchain controller; align allowed Auditor registration/provisioning with the UI; test stale JWTs after account disable/role change and each service's database revalidation. Public registration currently blocks ADMIN but does not explicitly reject AUDITOR.
8. Interface/API consistency: align owner cancellation, expose agreed account-detail/disable controls, and decide whether the remaining edit/document wrappers should be linked, removed or implemented.
9. Live acceptance evidence: update stale browser expectations and run the full roles/database/Fabric workflow. This explanation does not establish new test passes. The committed test-results-summary describes an earlier delivered frontend, not automatically the current main.

Possible later product features, separate from these current requirements: notifications, richer server-side search, a transaction-history/receipt screen, configurable scoring weights, multi-evaluator consensus and contract execution tracking. Payments, escrow, automatic legal enforcement, ML-based scoring, bid encryption/private-data collections and a complete production Fabric network are not implemented product capabilities in this snapshot.

## 11. Questions you can answer in a presentation

What is the project? “A tender-management application with five roles. Java enforces the workflow, PostgreSQL stores records and PDFs, and Hyperledger Fabric stores hashes that support integrity checks.”

Why both database and blockchain? “The database supports detailed queries and file storage. The separate ledger provides commitments against which selected database data can be compared.”

Is the whole PDF on blockchain? “No. The PDF is stored in PostgreSQL. Its SHA-256 is included in a bid payload whose hash is committed to Fabric.”

Who selects the winner? “The normal evaluator-finalization path selects it in Java after all relevant evaluations are finalized. The contract stores integrity records rather than ranking bids.”

Is the cheapest bid always the winner? “No. The highest equal-weighted technical/financial score wins; lower quoted amount is one later tie-break.”

Does the deadline open bids? “No. It closes intake. The assigned evaluator can open them after the separate opening time.”

Is frontend verification enough? “No. React guides the user, but backend services must enforce role, account state, ownership and timing.”

Does blockchain prevent all fraud? “No. It helps detect differences from committed data. Correct input, identity protection, access policy, the audit gate and operational checks still matter.”

Is it finished? “The integrated implementation covers the central role workflows. The source still differs from the board in the mandatory integrity gate, early-hold recovery, full lifecycle commitments and terminal-history coverage; live acceptance needs its own evidence.”

What should I learn first? Follow one tender and bid from the form through HTTP, controller, service, repository, hash service, gateway and Go contract. You do not need to memorize every import to explain that data flow accurately.

## 12. Using the line-by-line companion

Open TenderBlock_Code_Walkthrough.html in a browser. It is a self-contained local file with no CDN, API call or account requirement. Choose Overview to read this guide, then choose a file to see its original line, a line note and relevant function-purpose cards. Filter by Backend/Frontend/Hyperledger/Setup/Tests/Styling; search across paths, source and notes; jump to a line; use the GitHub link for the pinned source.

Line notes explain the syntax and local data flow; the purpose cards and chapters explain the business meaning. Repeated imports, separators and braces are intentionally brief. Read both columns for compressed one-line JSX/functions, where one physical line can contain several operations. The bundled coverage file states the exact included/excluded paths; original application source is preserved, not edited to add comments.
