TenderBlock code learning pack

Open TenderBlock_Code_Walkthrough.html in a web browser. It is self-contained and works without a server or Internet connection. Start with Overview, then use the file search/category controls and line-number jump.

TenderBlock_Study_Guide.md is the editable plain-text guide. Coverage.json lists the exact reviewed revision, included paths/line counts/checksums. Supporting_Files.json identifies reference/third-party/generated files not annotated line by line.

This pack explains source at commit 244c06c9e43b218eee02e05f3b5fa36a3f676fdd; it does not contain local secrets, actual database data, a running Fabric network or new live-test evidence. It does not modify project source.

TenderBlock_Study_Guide.pdf is a 14-page printable overview. Verification.json records learning-pack coverage/browser checks, not new TenderBlock application test results.
